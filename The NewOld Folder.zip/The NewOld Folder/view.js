function myImg01() {

var image1 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image2 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image3 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image4 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image5 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image6 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image7 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image8 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image9 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image10 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image11 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image12 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image13 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image14 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image15 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image16 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image17 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image18 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image19 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image20 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image21 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image22 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image23 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image24 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image25 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image26 = '<img id="cz2" src="red.png" alt="red">' + '<br>';


var getImgs = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26];
    document.getElementById("ImgL1").innerHTML = getImgs;
}

function myImg02() {

var image1 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image2 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image3 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image4 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image5 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image6 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image7 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image8 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image9 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image10 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image11 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image12 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image13 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image14 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image15 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image16 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image17 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image18 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image19 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image20 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image21 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image22 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image23 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image24 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image25 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image26 = '<img id="cz2" src="red.png" alt="red">' + '<br>';


var getImgs = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26];
    document.getElementById("ImgL2").innerHTML = getImgs;
}

function myImg03() {

var image1 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image2 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image3 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image4 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image5 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image6 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image7 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image8 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image9 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image10 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image11 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image12 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image13 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image14 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image15 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image16 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image17 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image18 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image19 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image20 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image21 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image22 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image23 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image24 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image25 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image26 = '<img id="cz2" src="red.png" alt="red">' + '<br>';


var getImgs = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26];
    document.getElementById("ImgL3").innerHTML = getImgs;
}

function myImg04() {

var image1 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image2 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image3 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image4 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image5 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image6 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image7 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image8 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image9 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image10 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image11 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image12 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image13 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image14 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image15 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image16 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image17 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image18 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image19 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image20 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image21 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image22 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image23 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image24 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image25 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image26 = '<img id="cz2" src="red.png" alt="red">' + '<br>';


var getImgs = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26];
    document.getElementById("ImgL4").innerHTML = getImgs;
}

function myImg05() {

var image1 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image2 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image3 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image4 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image5 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image6 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image7 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image8 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image9 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image10 = '<img id="bz2" src="blue.png" alt="blue">' + '<br>';
var image11 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image12 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image13 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image14 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image15 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image16 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image17 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image18 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image19 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image20 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image21 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image22 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image23 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image24 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image25 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image26 = '<img id="cz2" src="red.png" alt="red">' + '<br>';


var getImgs = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26];
    document.getElementById("ImgL5").innerHTML = getImgs;
}

function myImg06() {

var image1 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image2 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image3 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image4 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image5 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image6 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image7 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image8 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image9 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image10 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image11 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image12 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image13 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image14 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image15 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image16 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image17 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image18 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image19 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image20 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image21 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image22 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image23 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image24 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image25 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image26 = '<img id="cz2" src="red.png" alt="red">' + '<br>';


var getImgs = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26];
    document.getElementById("ImgL6").innerHTML = getImgs;
}

function myImg07() {

var image1 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image2 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image3 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image4 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image5 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image6 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image7 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image8 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image9 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image10 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image11 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image12 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image13 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image14 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image15 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image16 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image17 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image18 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image19 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image20 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image21 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image22 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image23 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image24 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image25 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image26 = '<img id="cz2" src="red.png" alt="red">' + '<br>';


var getImgs = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26];
    document.getElementById("ImgL7").innerHTML = getImgs;
}

function myImg08() {
	
var image1 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image2 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image3 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image4 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image5 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image6 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image7 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image8 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image9 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image10 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image11 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image12 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image13 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image14 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image15 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image16 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image17 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image18 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image19 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image20 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image21 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image22 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image23 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image24 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image25 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image26 = '<img id="cz2" src="red.png" alt="red">' + '<br>';


var getImgs = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26];
    document.getElementById("ImgL8").innerHTML = getImgs;
}

function myImg09() {

var image1 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image2 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image3 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image4 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image5 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image6 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image7 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image8 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image9 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image10 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image11 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image12 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image13 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image14 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image15 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image16 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image17 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image18 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image19 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image20 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image21 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image22 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image23 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image24 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image25 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image26 = '<img id="cz2" src="red.png" alt="red">' + '<br>';


var getImgs = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26];
    document.getElementById("ImgL9").innerHTML = getImgs;
}

function myImg010() {

var image1 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image2 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image3 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image4 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image5 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image6 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image7 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image8 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image9 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image10 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image11 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image12 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image13 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image14 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image15 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image16 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image17 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image18 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image19 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image20 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image21 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image22 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image23 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image24 = '<img id="az2" src="wht.png" alt="wht">' + '<br>';
var image25 = '<img id="cz2" src="red.png" alt="red">' + '<br>';
var image26 = '<img id="cz2" src="red.png" alt="red">' + '<br>';


var getImgs = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26];
    document.getElementById("ImgL10").innerHTML = getImgs;
}