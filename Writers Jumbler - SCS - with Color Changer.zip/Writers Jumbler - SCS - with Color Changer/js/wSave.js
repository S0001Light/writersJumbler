function setThis() {
	var value151 = document.getElementById("writersBlock").value;
	
	localStorage.setItem('data151', value151);
	
	alert("Your writing has been saved locally.");
}

function getThis() {
	
	var tripleZero1 = localStorage.getItem('data151');
	
	document.getElementById("writersBlock").defaultValue = tripleZero1;
}