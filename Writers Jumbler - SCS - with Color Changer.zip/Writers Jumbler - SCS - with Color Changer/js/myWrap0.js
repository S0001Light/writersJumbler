function sizes() {
  var x = document.getElementById("menu0").value;
  document.getElementById("writersBlock").style.fontSize = x;
}
function fonts() {
  var x = document.getElementById("menu1").value;
  document.getElementById("writersBlock").style.fontFamily = x;
}
function fontColors() {
  var x = document.getElementById("menu2").value;
  document.getElementById("writersBlock").style.color = x;
}
function fontShadows() {
  var x = document.getElementById("menu3").value;
  document.getElementById("writersBlock").style.textShadow = x;
}
function fontWeights() {
  var x = document.getElementById("menu4").value;
  document.getElementById("writersBlock").style.fontWeight = x;
}
function textVariants() {
  var x = document.getElementById("menu5").value;
  document.getElementById("writersBlock").style.fontVariant = x;
}
function textSpacings() {
  var x = document.getElementById("menu6").value;
  document.getElementById("writersBlock").style.letterSpacing = x;
}
function wordSpacings() {
  var x = document.getElementById("menu7").value;
  document.getElementById("writersBlock").style.wordSpacing = x;
}
function backgroundColors() {
  var x = document.getElementById("menu8").value;
  document.getElementById("writersBlock").style.backgroundColor = x;
}
function borderSizes() {
  var x = document.getElementById("menu9").value;
  document.getElementById("writersBlock").style.borderWidth = x;
}
function borderColors() {
  var x = document.getElementById("menu10").value;
  document.getElementById("writersBlock").style.borderColor = x;
}
function boxShadows() {
  var x = document.getElementById("menu11").value;
  document.getElementById("writersBlock").style.boxShadow = x;
}
function textAligns() {
  var x = document.getElementById("menu12").value;
  document.getElementById("writersBlock").style.textAlign = x;
}