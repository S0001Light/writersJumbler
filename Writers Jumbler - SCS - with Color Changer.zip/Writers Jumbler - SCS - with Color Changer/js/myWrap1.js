function myRap1() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);

var linewrp1 = document.getElementById("az1").value;
var linewrp2 = document.getElementById("bz1").value;
var linewrp3 = document.getElementById("cz1").value;
var linewrp4 = document.getElementById("dz1").value;
var linewrp5 = document.getElementById("ez1").value;
var linewrp6 = document.getElementById("fz1").value;
var linewrp7 = document.getElementById("gz1").value;
var linewrp8 = document.getElementById("hz1").value;
var linewrp9 = document.getElementById("iz1").value;
var linewrp10 = document.getElementById("jz1").value;

var rap1 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand1 + '</p>' + '<p style="padding-left:10px;">' + linewrp1 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap2 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand2 + '</p>' + '<p style="padding-left:10px;">' + linewrp2 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap3 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand3 + '</p>' + '<p style="padding-left:10px;">' + linewrp3 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap4 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand4 + '</p>' + '<p style="padding-left:10px;">' + linewrp4 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap5 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand5 + '</p>' + '<p style="padding-left:10px;">' + linewrp5 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap6 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand6 + '</p>' + '<p style="padding-left:10px;">' + linewrp6 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap7 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand7 + '</p>' + '<p style="padding-left:10px;">' + linewrp7 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap8 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand8 + '</p>' + '<p style="padding-left:10px;">' + linewrp8 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap9 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand9 + '</p>' + '<p style="padding-left:10px;">' + linewrp9 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap10 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand10 + '</p>' + '<p style="padding-left:10px;">' + linewrp10 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap1 = [rap1, rap2, rap3, rap4, rap5, rap6, rap7, rap8, rap9, rap10];
    document.getElementById("Rap1").innerHTML = getRap1.sort();
}