function setThis() {
	var value1 = document.getElementById("az1").value;
	var value2 = document.getElementById("bz1").value;
	var value3 = document.getElementById("cz1").value;
	var value4 = document.getElementById("dz1").value;
	var value5 = document.getElementById("ez1").value;
	var value6 = document.getElementById("fz1").value;
	var value7 = document.getElementById("gz1").value;
	var value8 = document.getElementById("hz1").value;
	var value9 = document.getElementById("iz1").value;
	var value10 = document.getElementById("jz1").value;
	
	var value11 = document.getElementById("kz1").value;
	var value12 = document.getElementById("lz1").value;
	var value13 = document.getElementById("mz1").value;
	var value14 = document.getElementById("nz1").value;
	var value15 = document.getElementById("oz1").value;
	var value16 = document.getElementById("pz1").value;
	var value17 = document.getElementById("qz1").value;
	var value18 = document.getElementById("rz1").value;
	var value19 = document.getElementById("sz1").value;
	var value20 = document.getElementById("tz1").value;
	
	var value21 = document.getElementById("uz1").value;
	var value22 = document.getElementById("vz1").value;
	var value23 = document.getElementById("wz1").value;
	var value24 = document.getElementById("xz1").value;
	var value25 = document.getElementById("yz1").value;
	var value26 = document.getElementById("zz1").value;
	var value27 = document.getElementById("aaz1").value;
	var value28 = document.getElementById("abz1").value;
	var value29 = document.getElementById("acz1").value;
	var value30 = document.getElementById("adz1").value;
	
	var value31 = document.getElementById("aez1").value;
	var value32 = document.getElementById("afz1").value;
	var value33 = document.getElementById("agz1").value;
	var value34 = document.getElementById("ahz1").value;
	var value35 = document.getElementById("aiz1").value;
	var value36 = document.getElementById("ajz1").value;
	var value37 = document.getElementById("akz1").value;
	var value38 = document.getElementById("alz1").value;
	var value39 = document.getElementById("amz1").value;
	var value40 = document.getElementById("anz1").value;
	
    localStorage.setItem('data61', value1);
	localStorage.setItem('data62', value2);
	localStorage.setItem('data63', value3);
	localStorage.setItem('data64', value4);
	localStorage.setItem('data65', value5);
	localStorage.setItem('data66', value6);
	localStorage.setItem('data67', value7);
	localStorage.setItem('data68', value8);
	localStorage.setItem('data69', value9);
	localStorage.setItem('data70', value10);
	
	localStorage.setItem('data71', value11);
	localStorage.setItem('data72', value12);
	localStorage.setItem('data73', value13);
	localStorage.setItem('data74', value14);
	localStorage.setItem('data75', value15);
	localStorage.setItem('data76', value16);
	localStorage.setItem('data77', value17);
	localStorage.setItem('data78', value18);
	localStorage.setItem('data79', value19);
	localStorage.setItem('data80', value20);
	
	localStorage.setItem('data81', value21);
	localStorage.setItem('data82', value22);
	localStorage.setItem('data83', value23);
	localStorage.setItem('data84', value24);
	localStorage.setItem('data85', value25);
	localStorage.setItem('data86', value26);
	localStorage.setItem('data87', value27);
	localStorage.setItem('data88', value28);
	localStorage.setItem('data89', value29);
	localStorage.setItem('data90', value30);
	
	localStorage.setItem('data91', value31);
	localStorage.setItem('data92', value32);
	localStorage.setItem('data93', value33);
	localStorage.setItem('data94', value34);
	localStorage.setItem('data95', value35);
	localStorage.setItem('data96', value36);
	localStorage.setItem('data97', value37);
	localStorage.setItem('data98', value38);
	localStorage.setItem('data99', value39);
	localStorage.setItem('data100', value40);
	
	alert("Your writings have been saved to your browsers local storage.");
}

function getThis() {
	
	var a1 = localStorage.getItem('data61');
	var b1 = localStorage.getItem('data62');
	var c1 = localStorage.getItem('data63');
    var d1 = localStorage.getItem('data64');
	var e1 = localStorage.getItem('data65');
	var f1 = localStorage.getItem('data66');
	var g1 = localStorage.getItem('data67');
	var h1 = localStorage.getItem('data68');
	var i1 = localStorage.getItem('data69');
	var j1 = localStorage.getItem('data70');
	
	var k1 = localStorage.getItem('data71');
	var l1 = localStorage.getItem('data72');
	var m1 = localStorage.getItem('data73');
    var n1 = localStorage.getItem('data74');
	var o1 = localStorage.getItem('data75');
	var p1 = localStorage.getItem('data76');
	var q1 = localStorage.getItem('data77');
	var r1 = localStorage.getItem('data78');
	var s1 = localStorage.getItem('data79');
	var t1 = localStorage.getItem('data80');
	
	var u1 = localStorage.getItem('data81');
	var v1 = localStorage.getItem('data82');
	var w1 = localStorage.getItem('data83');
    var x1 = localStorage.getItem('data84');
	var y1 = localStorage.getItem('data85');
	var z1 = localStorage.getItem('data86');
	var aa1 = localStorage.getItem('data87');
	var ab1 = localStorage.getItem('data88');
	var ac1 = localStorage.getItem('data89');
	var ad1 = localStorage.getItem('data90');
	
	var ae1 = localStorage.getItem('data91');
	var af1 = localStorage.getItem('data92');
	var ag1 = localStorage.getItem('data93');
    var ah1 = localStorage.getItem('data94');
	var ai1 = localStorage.getItem('data95');
	var aj1 = localStorage.getItem('data96');
	var ak1 = localStorage.getItem('data97');
	var al1 = localStorage.getItem('data98');
	var am1 = localStorage.getItem('data99');
	var an1 = localStorage.getItem('data100');
	
	document.getElementById("az1").defaultValue = a1;
	document.getElementById("bz1").defaultValue = b1;
	document.getElementById("cz1").defaultValue = c1;
	document.getElementById("dz1").defaultValue = d1;
	document.getElementById("ez1").defaultValue = e1;
	document.getElementById("fz1").defaultValue = f1;
	document.getElementById("gz1").defaultValue = g1;
	document.getElementById("hz1").defaultValue = h1;
	document.getElementById("iz1").defaultValue = i1;
	document.getElementById("jz1").defaultValue = j1;
	
	document.getElementById("kz1").defaultValue = k1;
	document.getElementById("lz1").defaultValue = l1;
	document.getElementById("mz1").defaultValue = m1;
	document.getElementById("nz1").defaultValue = n1;
	document.getElementById("oz1").defaultValue = o1;
	document.getElementById("pz1").defaultValue = p1;
	document.getElementById("qz1").defaultValue = q1;
	document.getElementById("rz1").defaultValue = r1;
	document.getElementById("sz1").defaultValue = s1;
	document.getElementById("tz1").defaultValue = t1;
	
	document.getElementById("uz1").defaultValue = u1;
	document.getElementById("vz1").defaultValue = v1;
	document.getElementById("wz1").defaultValue = w1;
	document.getElementById("xz1").defaultValue = x1;
	document.getElementById("yz1").defaultValue = y1;
	document.getElementById("zz1").defaultValue = z1;
	document.getElementById("aaz1").defaultValue = aa1;
	document.getElementById("abz1").defaultValue = ab1;
	document.getElementById("acz1").defaultValue = ac1;
	document.getElementById("adz1").defaultValue = ad1;
	
	document.getElementById("aez1").defaultValue = ae1;
	document.getElementById("afz1").defaultValue = af1;
	document.getElementById("agz1").defaultValue = ag1;
	document.getElementById("ahz1").defaultValue = ah1;
	document.getElementById("aiz1").defaultValue = ai1;
	document.getElementById("ajz1").defaultValue = aj1;
	document.getElementById("akz1").defaultValue = ak1;
	document.getElementById("alz1").defaultValue = al1;
	document.getElementById("amz1").defaultValue = am1;
	document.getElementById("anz1").defaultValue = an1;
	
}