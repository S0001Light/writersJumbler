function setThis() {
	var value1 = document.getElementById("az1").value;
	var value2 = document.getElementById("bz1").value;
	var value3 = document.getElementById("cz1").value;
	var value4 = document.getElementById("dz1").value;
	var value5 = document.getElementById("ez1").value;
	var value6 = document.getElementById("fz1").value;
	var value7 = document.getElementById("gz1").value;
	var value8 = document.getElementById("hz1").value;
	var value9 = document.getElementById("iz1").value;
	var value10 = document.getElementById("jz1").value;
	
	var value11 = document.getElementById("kz1").value;
	var value12 = document.getElementById("lz1").value;
	var value13 = document.getElementById("mz1").value;
	var value14 = document.getElementById("nz1").value;
	var value15 = document.getElementById("oz1").value;
	var value16 = document.getElementById("pz1").value;
	var value17 = document.getElementById("qz1").value;
	var value18 = document.getElementById("rz1").value;
	var value19 = document.getElementById("sz1").value;
	var value20 = document.getElementById("tz1").value;
	
	var value21 = document.getElementById("uz1").value;
	var value22 = document.getElementById("vz1").value;
	var value23 = document.getElementById("wz1").value;
	var value24 = document.getElementById("xz1").value;
	var value25 = document.getElementById("yz1").value;
	var value26 = document.getElementById("zz1").value;
	var value27 = document.getElementById("aaz1").value;
	var value28 = document.getElementById("abz1").value;
	var value29 = document.getElementById("acz1").value;
	var value30 = document.getElementById("adz1").value;
	
	localStorage.setItem('data31', value1);
	localStorage.setItem('data32', value2);
	localStorage.setItem('data33', value3);
	localStorage.setItem('data34', value4);
	localStorage.setItem('data35', value5);
	localStorage.setItem('data36', value6);
	localStorage.setItem('data37', value7);
	localStorage.setItem('data38', value8);
	localStorage.setItem('data39', value9);
	localStorage.setItem('data40', value10);
	
	localStorage.setItem('data41', value11);
	localStorage.setItem('data42', value12);
	localStorage.setItem('data43', value13);
	localStorage.setItem('data44', value14);
	localStorage.setItem('data45', value15);
	localStorage.setItem('data46', value16);
	localStorage.setItem('data47', value17);
	localStorage.setItem('data48', value18);
	localStorage.setItem('data49', value19);
	localStorage.setItem('data50', value20);
	
	localStorage.setItem('data51', value21);
	localStorage.setItem('data52', value22);
	localStorage.setItem('data53', value23);
	localStorage.setItem('data54', value24);
	localStorage.setItem('data55', value25);
	localStorage.setItem('data56', value26);
	localStorage.setItem('data57', value27);
	localStorage.setItem('data58', value28);
	localStorage.setItem('data59', value29);
	localStorage.setItem('data60', value30);
	
	alert("Your writings have been saved to your browsers local storage.");
}

function getThis() {
	
	var a1 = localStorage.getItem('data31');
	var b1 = localStorage.getItem('data32');
	var c1 = localStorage.getItem('data33');
    var d1 = localStorage.getItem('data34');
	var e1 = localStorage.getItem('data35');
	var f1 = localStorage.getItem('data36');
	var g1 = localStorage.getItem('data37');
	var h1 = localStorage.getItem('data38');
	var i1 = localStorage.getItem('data39');
	var j1 = localStorage.getItem('data40');
	
	var k1 = localStorage.getItem('data41');
	var l1 = localStorage.getItem('data42');
	var m1 = localStorage.getItem('data43');
    var n1 = localStorage.getItem('data44');
	var o1 = localStorage.getItem('data45');
	var p1 = localStorage.getItem('data46');
	var q1 = localStorage.getItem('data47');
	var r1 = localStorage.getItem('data48');
	var s1 = localStorage.getItem('data49');
	var t1 = localStorage.getItem('data50');
	
	var u1 = localStorage.getItem('data51');
	var v1 = localStorage.getItem('data52');
	var w1 = localStorage.getItem('data53');
    var x1 = localStorage.getItem('data54');
	var y1 = localStorage.getItem('data55');
	var z1 = localStorage.getItem('data56');
	var aa1 = localStorage.getItem('data57');
	var ab1 = localStorage.getItem('data58');
	var ac1 = localStorage.getItem('data59');
	var ad1 = localStorage.getItem('data60');
	
	document.getElementById("az1").defaultValue = a1;
	document.getElementById("bz1").defaultValue = b1;
	document.getElementById("cz1").defaultValue = c1;
	document.getElementById("dz1").defaultValue = d1;
	document.getElementById("ez1").defaultValue = e1;
	document.getElementById("fz1").defaultValue = f1;
	document.getElementById("gz1").defaultValue = g1;
	document.getElementById("hz1").defaultValue = h1;
	document.getElementById("iz1").defaultValue = i1;
	document.getElementById("jz1").defaultValue = j1;
	
	document.getElementById("kz1").defaultValue = k1;
	document.getElementById("lz1").defaultValue = l1;
	document.getElementById("mz1").defaultValue = m1;
	document.getElementById("nz1").defaultValue = n1;
	document.getElementById("oz1").defaultValue = o1;
	document.getElementById("pz1").defaultValue = p1;
	document.getElementById("qz1").defaultValue = q1;
	document.getElementById("rz1").defaultValue = r1;
	document.getElementById("sz1").defaultValue = s1;
	document.getElementById("tz1").defaultValue = t1;
	
	document.getElementById("uz1").defaultValue = u1;
	document.getElementById("vz1").defaultValue = v1;
	document.getElementById("wz1").defaultValue = w1;
	document.getElementById("xz1").defaultValue = x1;
	document.getElementById("yz1").defaultValue = y1;
	document.getElementById("zz1").defaultValue = z1;
	document.getElementById("aaz1").defaultValue = aa1;
	document.getElementById("abz1").defaultValue = ab1;
	document.getElementById("acz1").defaultValue = ac1;
	document.getElementById("adz1").defaultValue = ad1;
	
}