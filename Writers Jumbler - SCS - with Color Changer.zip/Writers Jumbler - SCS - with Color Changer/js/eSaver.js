function setThis() {
	var value1 = document.getElementById("az1").value;
	var value2 = document.getElementById("bz1").value;
	var value3 = document.getElementById("cz1").value;
	var value4 = document.getElementById("dz1").value;
	var value5 = document.getElementById("ez1").value;
	var value6 = document.getElementById("fz1").value;
	var value7 = document.getElementById("gz1").value;
	var value8 = document.getElementById("hz1").value;
	var value9 = document.getElementById("iz1").value;
	var value10 = document.getElementById("jz1").value;
	
	var value11 = document.getElementById("kz1").value;
	var value12 = document.getElementById("lz1").value;
	var value13 = document.getElementById("mz1").value;
	var value14 = document.getElementById("nz1").value;
	var value15 = document.getElementById("oz1").value;
	var value16 = document.getElementById("pz1").value;
	var value17 = document.getElementById("qz1").value;
	var value18 = document.getElementById("rz1").value;
	var value19 = document.getElementById("sz1").value;
	var value20 = document.getElementById("tz1").value;
	
	var value21 = document.getElementById("uz1").value;
	var value22 = document.getElementById("vz1").value;
	var value23 = document.getElementById("wz1").value;
	var value24 = document.getElementById("xz1").value;
	var value25 = document.getElementById("yz1").value;
	var value26 = document.getElementById("zz1").value;
	var value27 = document.getElementById("aaz1").value;
	var value28 = document.getElementById("abz1").value;
	var value29 = document.getElementById("acz1").value;
	var value30 = document.getElementById("adz1").value;
	
	var value31 = document.getElementById("aez1").value;
	var value32 = document.getElementById("afz1").value;
	var value33 = document.getElementById("agz1").value;
	var value34 = document.getElementById("ahz1").value;
	var value35 = document.getElementById("aiz1").value;
	var value36 = document.getElementById("ajz1").value;
	var value37 = document.getElementById("akz1").value;
	var value38 = document.getElementById("alz1").value;
	var value39 = document.getElementById("amz1").value;
	var value40 = document.getElementById("anz1").value;
	
	var value41 = document.getElementById("aoz1").value;
	var value42 = document.getElementById("apz1").value;
	var value43 = document.getElementById("aqz1").value;
	var value44 = document.getElementById("arz1").value;
	var value45 = document.getElementById("asz1").value;
	var value46 = document.getElementById("atz1").value;
	var value47 = document.getElementById("auz1").value;
	var value48 = document.getElementById("avz1").value;
	var value49 = document.getElementById("awz1").value;
	var value50 = document.getElementById("axz1").value;
	
	localStorage.setItem('data101', value1);
	localStorage.setItem('data102', value2);
	localStorage.setItem('data103', value3);
	localStorage.setItem('data104', value4);
	localStorage.setItem('data105', value5);
	localStorage.setItem('data106', value6);
	localStorage.setItem('data107', value7);
	localStorage.setItem('data108', value8);
	localStorage.setItem('data109', value9);
	localStorage.setItem('data110', value10);
	
	localStorage.setItem('data111', value11);
	localStorage.setItem('data112', value12);
	localStorage.setItem('data113', value13);
	localStorage.setItem('data114', value14);
	localStorage.setItem('data115', value15);
	localStorage.setItem('data116', value16);
	localStorage.setItem('data117', value17);
	localStorage.setItem('data118', value18);
	localStorage.setItem('data119', value19);
	localStorage.setItem('data120', value20);
	
	localStorage.setItem('data121', value21);
	localStorage.setItem('data122', value22);
	localStorage.setItem('data123', value23);
	localStorage.setItem('data124', value24);
	localStorage.setItem('data125', value25);
	localStorage.setItem('data126', value26);
	localStorage.setItem('data127', value27);
	localStorage.setItem('data128', value28);
	localStorage.setItem('data129', value29);
	localStorage.setItem('data130', value30);
	
	localStorage.setItem('data131', value31);
	localStorage.setItem('data132', value32);
	localStorage.setItem('data133', value33);
	localStorage.setItem('data134', value34);
	localStorage.setItem('data135', value35);
	localStorage.setItem('data136', value36);
	localStorage.setItem('data137', value37);
	localStorage.setItem('data138', value38);
	localStorage.setItem('data139', value39);
	localStorage.setItem('data140', value40);
	
	localStorage.setItem('data141', value41);
	localStorage.setItem('data142', value42);
	localStorage.setItem('data143', value43);
	localStorage.setItem('data144', value44);
	localStorage.setItem('data145', value45);
	localStorage.setItem('data146', value46);
	localStorage.setItem('data147', value47);
	localStorage.setItem('data148', value48);
	localStorage.setItem('data149', value49);
	localStorage.setItem('data150', value50);
	
	alert("Your writings have been saved to your browsers local storage.");
}

function getThis() {
	
	var a1 = localStorage.getItem('data101');
	var b1 = localStorage.getItem('data102');
	var c1 = localStorage.getItem('data103');
    var d1 = localStorage.getItem('data104');
	var e1 = localStorage.getItem('data105');
	var f1 = localStorage.getItem('data106');
	var g1 = localStorage.getItem('data107');
	var h1 = localStorage.getItem('data108');
	var i1 = localStorage.getItem('data109');
	var j1 = localStorage.getItem('data110');
	
	var k1 = localStorage.getItem('data111');
	var l1 = localStorage.getItem('data112');
	var m1 = localStorage.getItem('data113');
    var n1 = localStorage.getItem('data114');
	var o1 = localStorage.getItem('data115');
	var p1 = localStorage.getItem('data116');
	var q1 = localStorage.getItem('data117');
	var r1 = localStorage.getItem('data118');
	var s1 = localStorage.getItem('data119');
	var t1 = localStorage.getItem('data120');
	
	var u1 = localStorage.getItem('data121');
	var v1 = localStorage.getItem('data122');
	var w1 = localStorage.getItem('data123');
    var x1 = localStorage.getItem('data124');
	var y1 = localStorage.getItem('data125');
	var z1 = localStorage.getItem('data126');
	var aa1 = localStorage.getItem('data127');
	var ab1 = localStorage.getItem('data128');
	var ac1 = localStorage.getItem('data129');
	var ad1 = localStorage.getItem('data130');
	
	var ae1 = localStorage.getItem('data131');
	var af1 = localStorage.getItem('data132');
	var ag1 = localStorage.getItem('data133');
    var ah1 = localStorage.getItem('data134');
	var ai1 = localStorage.getItem('data135');
	var aj1 = localStorage.getItem('data136');
	var ak1 = localStorage.getItem('data137');
	var al1 = localStorage.getItem('data138');
	var am1 = localStorage.getItem('data139');
	var an1 = localStorage.getItem('data140');
	
	var ao1 = localStorage.getItem('data141');
	var ap1 = localStorage.getItem('data142');
	var aq1 = localStorage.getItem('data143');
    var ar1 = localStorage.getItem('data144');
	var as1 = localStorage.getItem('data145');
	var at1 = localStorage.getItem('data146');
	var au1 = localStorage.getItem('data147');
	var av1 = localStorage.getItem('data148');
	var aw1 = localStorage.getItem('data149');
	var ax1 = localStorage.getItem('data150');
	
	document.getElementById("az1").defaultValue = a1;
	document.getElementById("bz1").defaultValue = b1;
	document.getElementById("cz1").defaultValue = c1;
	document.getElementById("dz1").defaultValue = d1;
	document.getElementById("ez1").defaultValue = e1;
	document.getElementById("fz1").defaultValue = f1;
	document.getElementById("gz1").defaultValue = g1;
	document.getElementById("hz1").defaultValue = h1;
	document.getElementById("iz1").defaultValue = i1;
	document.getElementById("jz1").defaultValue = j1;
	
	document.getElementById("kz1").defaultValue = k1;
	document.getElementById("lz1").defaultValue = l1;
	document.getElementById("mz1").defaultValue = m1;
	document.getElementById("nz1").defaultValue = n1;
	document.getElementById("oz1").defaultValue = o1;
	document.getElementById("pz1").defaultValue = p1;
	document.getElementById("qz1").defaultValue = q1;
	document.getElementById("rz1").defaultValue = r1;
	document.getElementById("sz1").defaultValue = s1;
	document.getElementById("tz1").defaultValue = t1;
	
	document.getElementById("uz1").defaultValue = u1;
	document.getElementById("vz1").defaultValue = v1;
	document.getElementById("wz1").defaultValue = w1;
	document.getElementById("xz1").defaultValue = x1;
	document.getElementById("yz1").defaultValue = y1;
	document.getElementById("zz1").defaultValue = z1;
	document.getElementById("aaz1").defaultValue = aa1;
	document.getElementById("abz1").defaultValue = ab1;
	document.getElementById("acz1").defaultValue = ac1;
	document.getElementById("adz1").defaultValue = ad1;
	
	document.getElementById("aez1").defaultValue = ae1;
	document.getElementById("afz1").defaultValue = af1;
	document.getElementById("agz1").defaultValue = ag1;
	document.getElementById("ahz1").defaultValue = ah1;
	document.getElementById("aiz1").defaultValue = ai1;
	document.getElementById("ajz1").defaultValue = aj1;
	document.getElementById("akz1").defaultValue = ak1;
	document.getElementById("alz1").defaultValue = al1;
	document.getElementById("amz1").defaultValue = am1;
	document.getElementById("anz1").defaultValue = an1;
	
	document.getElementById("aoz1").defaultValue = ao1;
	document.getElementById("apz1").defaultValue = ap1;
	document.getElementById("aqz1").defaultValue = aq1;
	document.getElementById("arz1").defaultValue = ar1;
	document.getElementById("asz1").defaultValue = as1;
	document.getElementById("atz1").defaultValue = at1;
	document.getElementById("auz1").defaultValue = au1;
	document.getElementById("avz1").defaultValue = av1;
	document.getElementById("awz1").defaultValue = aw1;
	document.getElementById("axz1").defaultValue = ax1;
}