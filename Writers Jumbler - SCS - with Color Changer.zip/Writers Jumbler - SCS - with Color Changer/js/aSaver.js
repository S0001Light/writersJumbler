function setThis() {
	var value1 = document.getElementById("az1").value;
	var value2 = document.getElementById("bz1").value;
	var value3 = document.getElementById("cz1").value;
	var value4 = document.getElementById("dz1").value;
	var value5 = document.getElementById("ez1").value;
	var value6 = document.getElementById("fz1").value;
	var value7 = document.getElementById("gz1").value;
	var value8 = document.getElementById("hz1").value;
	var value9 = document.getElementById("iz1").value;
	var value10 = document.getElementById("jz1").value;
	
	localStorage.setItem('data1', value1);
	localStorage.setItem('data2', value2);
	localStorage.setItem('data3', value3);
	localStorage.setItem('data4', value4);
	localStorage.setItem('data5', value5);
	localStorage.setItem('data6', value6);
	localStorage.setItem('data7', value7);
	localStorage.setItem('data8', value8);
	localStorage.setItem('data9', value9);
	localStorage.setItem('data10', value10);
	
	alert("Your writings have been saved to your browsers local storage.");
}

function getThis() {
	
	var a1 = localStorage.getItem('data1');
	var b1 = localStorage.getItem('data2');
	var c1 = localStorage.getItem('data3');
    var d1 = localStorage.getItem('data4');
	var e1 = localStorage.getItem('data5');
	var f1 = localStorage.getItem('data6');
	var g1 = localStorage.getItem('data7');
	var h1 = localStorage.getItem('data8');
	var i1 = localStorage.getItem('data9');
	var j1 = localStorage.getItem('data10');
	
	document.getElementById("az1").defaultValue = a1;
	document.getElementById("bz1").defaultValue = b1;
	document.getElementById("cz1").defaultValue = c1;
	document.getElementById("dz1").defaultValue = d1;
	document.getElementById("ez1").defaultValue = e1;
	document.getElementById("fz1").defaultValue = f1;
	document.getElementById("gz1").defaultValue = g1;
	document.getElementById("hz1").defaultValue = h1;
	document.getElementById("iz1").defaultValue = i1;
	document.getElementById("jz1").defaultValue = j1;
}