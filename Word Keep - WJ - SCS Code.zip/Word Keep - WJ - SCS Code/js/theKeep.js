function dotClick1() {
	if(document.getElementById("scSaz1").style.visibility == "visible") {
		document.getElementById("scSaz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSaz1").style.visibility = "visible";
	}
}

function dotClick2() {
	if(document.getElementById("scSbz1").style.visibility == "visible") {
		document.getElementById("scSbz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSbz1").style.visibility = "visible";
	}
}

function dotClick3() {
	if(document.getElementById("scScz1").style.visibility == "visible") {
		document.getElementById("scScz1").style.visibility = "hidden";
	} else {
		document.getElementById("scScz1").style.visibility = "visible";
	}
}

function dotClick4() {
	if(document.getElementById("scSdz1").style.visibility == "visible") {
		document.getElementById("scSdz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSdz1").style.visibility = "visible";
	}
}

function dotClick5() {
	if(document.getElementById("scSez1").style.visibility == "visible") {
		document.getElementById("scSez1").style.visibility = "hidden";
	} else {
		document.getElementById("scSez1").style.visibility = "visible";
	}
}

function dotClick6() {
	if(document.getElementById("scSfz1").style.visibility == "visible") {
		document.getElementById("scSfz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSfz1").style.visibility = "visible";
	}
}

function dotClick7() {
	if(document.getElementById("scSgz1").style.visibility == "visible") {
		document.getElementById("scSgz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSgz1").style.visibility = "visible";
	}
}

function dotClick8() {
	if(document.getElementById("scShz1").style.visibility == "visible") {
		document.getElementById("scShz1").style.visibility = "hidden";
	} else {
		document.getElementById("scShz1").style.visibility = "visible";
	}
}

function dotClick9() {
	if(document.getElementById("scSiz1").style.visibility == "visible") {
		document.getElementById("scSiz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSiz1").style.visibility = "visible";
	}
}

function dotClick10() {
	if(document.getElementById("scSjz1").style.visibility == "visible") {
		document.getElementById("scSjz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSjz1").style.visibility = "visible";
	}
}

function dotClick11() {
	if(document.getElementById("scSkz1").style.visibility == "visible") {
		document.getElementById("scSkz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSkz1").style.visibility = "visible";
	}
}

function dotClick12() {
	if(document.getElementById("scSlz1").style.visibility == "visible") {
		document.getElementById("scSlz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSlz1").style.visibility = "visible";
	}
}

function dotClick13() {
	if(document.getElementById("scSmz1").style.visibility == "visible") {
		document.getElementById("scSmz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSmz1").style.visibility = "visible";
	}
}

function dotClick14() {
	if(document.getElementById("scSnz1").style.visibility == "visible") {
		document.getElementById("scSnz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSnz1").style.visibility = "visible";
	}
}

function dotClick15() {
	if(document.getElementById("scSoz1").style.visibility == "visible") {
		document.getElementById("scSoz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSoz1").style.visibility = "visible";
	}
}

function dotClick16() {
	if(document.getElementById("scSpz1").style.visibility == "visible") {
		document.getElementById("scSpz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSpz1").style.visibility = "visible";
	}
}

function dotClick17() {
	if(document.getElementById("scSqz1").style.visibility == "visible") {
		document.getElementById("scSqz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSqz1").style.visibility = "visible";
	}
}

function dotClick18() {
	if(document.getElementById("scSrz1").style.visibility == "visible") {
		document.getElementById("scSrz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSrz1").style.visibility = "visible";
	}
}

function dotClick19() {
	if(document.getElementById("scSsz1").style.visibility == "visible") {
		document.getElementById("scSsz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSsz1").style.visibility = "visible";
	}
}

function dotClick20() {
	if(document.getElementById("scStz1").style.visibility == "visible") {
		document.getElementById("scStz1").style.visibility = "hidden";
	} else {
		document.getElementById("scStz1").style.visibility = "visible";
	}
}

function dotClick21() {
	if(document.getElementById("scSuz1").style.visibility == "visible") {
		document.getElementById("scSuz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSuz1").style.visibility = "visible";
	}
}

function dotClick22() {
	if(document.getElementById("scSvz1").style.visibility == "visible") {
		document.getElementById("scSvz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSvz1").style.visibility = "visible";
	}
}

function dotClick23() {
	if(document.getElementById("scSwz1").style.visibility == "visible") {
		document.getElementById("scSwz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSwz1").style.visibility = "visible";
	}
}

function dotClick24() {
	if(document.getElementById("scSxz1").style.visibility == "visible") {
		document.getElementById("scSxz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSxz1").style.visibility = "visible";
	}
}

function dotClick25() {
	if(document.getElementById("scSyz1").style.visibility == "visible") {
		document.getElementById("scSyz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSyz1").style.visibility = "visible";
	}
}

function dotClick26() {
	if(document.getElementById("scSzz1").style.visibility == "visible") {
		document.getElementById("scSzz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSzz1").style.visibility = "visible";
	}
}

function dotClick27() {
	if(document.getElementById("scSaaz1").style.visibility == "visible") {
		document.getElementById("scSaaz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSaaz1").style.visibility = "visible";
	}
}

function dotClick28() {
	if(document.getElementById("scSabz1").style.visibility == "visible") {
		document.getElementById("scSabz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSabz1").style.visibility = "visible";
	}
}

function dotClick29() {
	if(document.getElementById("scSacz1").style.visibility == "visible") {
		document.getElementById("scSacz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSacz1").style.visibility = "visible";
	}
}

function dotClick30() {
	if(document.getElementById("scSadz1").style.visibility == "visible") {
		document.getElementById("scSadz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSadz1").style.visibility = "visible";
	}
}

function dotClick31() {
	if(document.getElementById("scSaez1").style.visibility == "visible") {
		document.getElementById("scSaez1").style.visibility = "hidden";
	} else {
		document.getElementById("scSaez1").style.visibility = "visible";
	}
}

function dotClick32() {
	if(document.getElementById("scSafz1").style.visibility == "visible") {
		document.getElementById("scSafz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSafz1").style.visibility = "visible";
	}
}

function dotClick33() {
	if(document.getElementById("scSagz1").style.visibility == "visible") {
		document.getElementById("scSagz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSagz1").style.visibility = "visible";
	}
}

function dotClick34() {
	if(document.getElementById("scSahz1").style.visibility == "visible") {
		document.getElementById("scSahz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSahz1").style.visibility = "visible";
	}
}

function dotClick35() {
	if(document.getElementById("scSaiz1").style.visibility == "visible") {
		document.getElementById("scSaiz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSaiz1").style.visibility = "visible";
	}
}

function dotClick36() {
	if(document.getElementById("scSajz1").style.visibility == "visible") {
		document.getElementById("scSajz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSajz1").style.visibility = "visible";
	}
}

function dotClick37() {
	if(document.getElementById("scSakz1").style.visibility == "visible") {
		document.getElementById("scSakz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSakz1").style.visibility = "visible";
	}
}

function dotClick38() {
	if(document.getElementById("scSalz1").style.visibility == "visible") {
		document.getElementById("scSalz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSalz1").style.visibility = "visible";
	}
}

function dotClick39() {
	if(document.getElementById("scSamz1").style.visibility == "visible") {
		document.getElementById("scSamz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSamz1").style.visibility = "visible";
	}
}

function dotClick40() {
	if(document.getElementById("scSanz1").style.visibility == "visible") {
		document.getElementById("scSanz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSanz1").style.visibility = "visible";
	}
}

function dotClick41() {
	if(document.getElementById("scSaoz1").style.visibility == "visible") {
		document.getElementById("scSaoz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSaoz1").style.visibility = "visible";
	}
}

function dotClick42() {
	if(document.getElementById("scSapz1").style.visibility == "visible") {
		document.getElementById("scSapz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSapz1").style.visibility = "visible";
	}
}

function dotClick43() {
	if(document.getElementById("scSaqz1").style.visibility == "visible") {
		document.getElementById("scSaqz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSaqz1").style.visibility = "visible";
	}
}

function dotClick44() {
	if(document.getElementById("scSarz1").style.visibility == "visible") {
		document.getElementById("scSarz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSarz1").style.visibility = "visible";
	}
}

function dotClick45() {
	if(document.getElementById("scSasz1").style.visibility == "visible") {
		document.getElementById("scSasz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSasz1").style.visibility = "visible";
	}
}

function dotClick46() {
	if(document.getElementById("scSatz1").style.visibility == "visible") {
		document.getElementById("scSatz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSatz1").style.visibility = "visible";
	}
}

function dotClick47() {
	if(document.getElementById("scSauz1").style.visibility == "visible") {
		document.getElementById("scSauz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSauz1").style.visibility = "visible";
	}
}

function dotClick48() {
	if(document.getElementById("scSavz1").style.visibility == "visible") {
		document.getElementById("scSavz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSavz1").style.visibility = "visible";
	}
}

function dotClick49() {
	if(document.getElementById("scSawz1").style.visibility == "visible") {
		document.getElementById("scSawz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSawz1").style.visibility = "visible";
	}
}

function dotClick50() {
	if(document.getElementById("scSaxz1").style.visibility == "visible") {
		document.getElementById("scSaxz1").style.visibility = "hidden";
	} else {
		document.getElementById("scSaxz1").style.visibility = "visible";
	}
}