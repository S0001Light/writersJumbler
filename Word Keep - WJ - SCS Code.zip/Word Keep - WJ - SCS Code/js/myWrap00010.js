function myRap00001() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);

var linewrp1 = document.getElementById("az1").value;
var linewrp2 = document.getElementById("bz1").value;
var linewrp3 = document.getElementById("cz1").value;
var linewrp4 = document.getElementById("dz1").value;
var linewrp5 = document.getElementById("ez1").value;

var rap1 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand1 + '</p>' + '<p id="scSaz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick1()">' + linewrp1 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap2 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand2 + '</p>' + '<p id="scSbz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick2()">' + linewrp2 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap3 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand3 + '</p>' + '<p id="scScz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick3()">' + linewrp3 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap4 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand4 + '</p>' + '<p id="scSdz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick4()">' + linewrp4 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap5 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand5 + '</p>' + '<p id="scSez1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick5()">' + linewrp5 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap00001 = [rap1, rap2, rap3, rap4, rap5];
    document.getElementById("RapColumn00001").innerHTML = getRap00001.sort();
}

function myRap00002() {

var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);

var linewrp6 = document.getElementById("fz1").value;
var linewrp7 = document.getElementById("gz1").value;
var linewrp8 = document.getElementById("hz1").value;
var linewrp9 = document.getElementById("iz1").value;
var linewrp10 = document.getElementById("jz1").value;

var rap6 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand6 + '</p>' + '<p id="scSfz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick6()">' + linewrp6 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap7 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand7 + '</p>' + '<p id="scSgz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick7()">' + linewrp7 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap8 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand8 + '</p>' + '<p id="scShz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick8()">' + linewrp8 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap9 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand9 + '</p>' + '<p id="scSiz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick9()">' + linewrp9 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap10 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand10 + '</p>' + '<p id="scSjz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick10()">' + linewrp10 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap00002 = [rap6, rap7, rap8, rap9, rap10];
    document.getElementById("RapColumn00002").innerHTML = getRap00002.sort();
}

function myRap00003() {
	
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);

var linewrp11 = document.getElementById("kz1").value;
var linewrp12 = document.getElementById("lz1").value;
var linewrp13 = document.getElementById("mz1").value;
var linewrp14 = document.getElementById("nz1").value;
var linewrp15 = document.getElementById("oz1").value;

var rap11 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand11 + '</p>' + '<p id="scSkz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick11()">' + linewrp11 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap12 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand12 + '</p>' + '<p id="scSlz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick12()">' + linewrp12 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap13 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand13 + '</p>' + '<p id="scSmz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick13()">' + linewrp13 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap14 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand14 + '</p>' + '<p id="scSnz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick14()">' + linewrp14 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap15 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand15 + '</p>' + '<p id="scSoz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick15()">' + linewrp15 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap00003 = [rap11, rap12, rap13, rap14, rap15];
    document.getElementById("RapColumn00003").innerHTML = getRap00003.sort();
}

function myRap00004() {

var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);

var linewrp16 = document.getElementById("pz1").value;
var linewrp17 = document.getElementById("qz1").value;
var linewrp18 = document.getElementById("rz1").value;
var linewrp19 = document.getElementById("sz1").value;
var linewrp20 = document.getElementById("tz1").value;

var rap16 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand16 + '</p>' + '<p id="scSpz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick16()">' + linewrp16 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap17 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand17 + '</p>' + '<p id="scSqz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick17()">' + linewrp17 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap18 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand18 + '</p>' + '<p id="scSrz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick18()">' + linewrp18 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap19 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand19 + '</p>' + '<p id="scSsz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick19()">' + linewrp19 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap20 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand20 + '</p>' + '<p id="scStz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick20()">' + linewrp20 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap00004 = [rap16, rap17, rap18, rap19, rap20];
    document.getElementById("RapColumn00004").innerHTML = getRap00004.sort();
}

function myRap00005() {

var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);

var linewrp21 = document.getElementById("uz1").value;
var linewrp22 = document.getElementById("vz1").value;
var linewrp23 = document.getElementById("wz1").value;
var linewrp24 = document.getElementById("xz1").value;
var linewrp25 = document.getElementById("yz1").value;

var rap21 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand21 + '</p>' + '<p id="scSuz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick21()">' + linewrp21 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap22 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand22 + '</p>' + '<p id="scSvz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick22()">' + linewrp22 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap23 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand23 + '</p>' + '<p id="scSwz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick23()">' + linewrp23 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap24 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand24 + '</p>' + '<p id="scSxz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick24()">' + linewrp24 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap25 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand25 + '</p>' + '<p id="scSyz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick25()">' + linewrp25 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap00005 = [rap21, rap22, rap23, rap24, rap25];
    document.getElementById("RapColumn00005").innerHTML = getRap00005.sort();
}

function myRap00006() {

var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);

var linewrp26 = document.getElementById("zz1").value;
var linewrp27 = document.getElementById("aaz1").value;
var linewrp28 = document.getElementById("abz1").value;
var linewrp29 = document.getElementById("acz1").value;
var linewrp30 = document.getElementById("adz1").value;

var rap26 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand26 + '</p>' + '<p id="scSzz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick26()">' + linewrp26 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap27 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand27 + '</p>' + '<p id="scSaaz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick27()">' + linewrp27 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap28 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand28 + '</p>' + '<p id="scSabz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick28()">' + linewrp28 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap29 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand29 + '</p>' + '<p id="scSacz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick29()">' + linewrp29 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap30 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand30 + '</p>' + '<p id="scSadz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick30()">' + linewrp30 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap00006 = [rap26, rap27, rap28, rap29, rap30];
    document.getElementById("RapColumn00006").innerHTML = getRap00006.sort();
}

function myRap00007() {
	
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);
var numRand33 = Math.floor((Math.random() * 10) + 1);
var numRand34 = Math.floor((Math.random() * 10) + 1);
var numRand35 = Math.floor((Math.random() * 10) + 1);

var linewrp31 = document.getElementById("aez1").value;
var linewrp32 = document.getElementById("afz1").value;
var linewrp33 = document.getElementById("agz1").value;
var linewrp34 = document.getElementById("ahz1").value;
var linewrp35 = document.getElementById("aiz1").value;

var rap31 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand31 + '</p>' + '<p id="scSaez1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick31()">' + linewrp31 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap32 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand32 + '</p>' + '<p id="scSafz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick32()">' + linewrp32 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap33 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand33 + '</p>' + '<p id="scSagz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick33()">' + linewrp33 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap34 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand34 + '</p>' + '<p id="scSahz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick34()">' + linewrp34 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap35 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand35 + '</p>' + '<p id="scSaiz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick35()">' + linewrp35 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap00007 = [rap31, rap32, rap33, rap34, rap35];
    document.getElementById("RapColumn00007").innerHTML = getRap00007.sort();
}

function myRap00008() {

var numRand36 = Math.floor((Math.random() * 10) + 1);
var numRand37 = Math.floor((Math.random() * 10) + 1);
var numRand38 = Math.floor((Math.random() * 10) + 1);
var numRand39 = Math.floor((Math.random() * 10) + 1);
var numRand40 = Math.floor((Math.random() * 10) + 1);

var linewrp36 = document.getElementById("ajz1").value;
var linewrp37 = document.getElementById("akz1").value;
var linewrp38 = document.getElementById("alz1").value;
var linewrp39 = document.getElementById("amz1").value;
var linewrp40 = document.getElementById("anz1").value;

var rap36 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand36 + '</p>' + '<p id="scSajz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick36()">' + linewrp36 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap37 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand37 + '</p>' + '<p id="scSakz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick37()">' + linewrp37 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap38 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand38 + '</p>' + '<p id="scSalz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick38()">' + linewrp38 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap39 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand39 + '</p>' + '<p id="scSamz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick39()">' + linewrp39 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap40 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand40 + '</p>' + '<p id="scSanz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick40()">' + linewrp40 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap00008 = [rap36, rap37, rap38, rap39, rap40];
    document.getElementById("RapColumn00008").innerHTML = getRap00008.sort();
}

function myRap00009() {

var numRand41 = Math.floor((Math.random() * 10) + 1);
var numRand42 = Math.floor((Math.random() * 10) + 1);
var numRand43 = Math.floor((Math.random() * 10) + 1);
var numRand44 = Math.floor((Math.random() * 10) + 1);
var numRand45 = Math.floor((Math.random() * 10) + 1);

var linewrp41 = document.getElementById("aoz1").value;
var linewrp42 = document.getElementById("apz1").value;
var linewrp43 = document.getElementById("aqz1").value;
var linewrp44 = document.getElementById("arz1").value;
var linewrp45 = document.getElementById("asz1").value;

var rap41 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand41 + '</p>' + '<p id="scSaoz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick41()">' + linewrp41 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap42 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand42 + '</p>' + '<p id="scSapz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick42()">' + linewrp42 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap43 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand43 + '</p>' + '<p id="scSaqz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick43()">' + linewrp43 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap44 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand44 + '</p>' + '<p id="scSarz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick44()">' + linewrp44 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap45 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand45 + '</p>' + '<p id="scSasz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick45()">' + linewrp45 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap00009 = [rap41, rap42, rap43, rap44, rap45];
    document.getElementById("RapColumn00009").innerHTML = getRap00009.sort();
}

function myRap00010() {

var numRand46 = Math.floor((Math.random() * 10) + 1);
var numRand47 = Math.floor((Math.random() * 10) + 1);
var numRand48 = Math.floor((Math.random() * 10) + 1);
var numRand49 = Math.floor((Math.random() * 10) + 1);
var numRand50 = Math.floor((Math.random() * 10) + 1);

var linewrp46 = document.getElementById("atz1").value;
var linewrp47 = document.getElementById("auz1").value;
var linewrp48 = document.getElementById("avz1").value;
var linewrp49 = document.getElementById("awz1").value;
var linewrp50 = document.getElementById("axz1").value;

var rap46 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand46 + '</p>' + '<p id="scSatz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick46()">' + linewrp46 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap47 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand47 + '</p>' + '<p id="scSauz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick47()">' + linewrp47 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap48 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand48 + '</p>' + '<p id="scSavz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick48()">' + linewrp48 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap49 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand49 + '</p>' + '<p id="scSawz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick49()">' + linewrp49 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap50 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand50 + '</p>' + '<p id="scSaxz1" style="padding-left:10px; font-size:12px; font-family:monospace;" ondblclick="dotClick50()">' + linewrp50 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap00010 = [rap46, rap47, rap48, rap49, rap50];
    document.getElementById("RapColumn00010").innerHTML = getRap00010.sort();
}
